package app.cyberzen.easytax;

public class MenuLogOut {

}
