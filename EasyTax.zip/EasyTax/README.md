# EasyTax
A tax application that will keep records of all your income, business supplies, expenses, and tax transactions and will automatically calculate your tax liability for the particular period. It will be extremely helpful for all types of taxpayers.

#Team Members:
##1. Alex La N01313354
##2. Gireesh Sharma-Singh N01193783
##3. Ravindra Ramdhanie N01283199
##4. Yogeshwar Mahadeo N01236915

#Github Link
##https://github.com/AlexLa00/EasyTax.git